<?php

global $_MODULE;
$_MODULE = array();

$_MODULE['<{pspagebuilder}prestashop>blockspecials_c19ed4ea98cbf319735f6d09bde6c757'] = 'Bloque promociones especiales';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_530c88f8210e022b39128e3f0409bbcf'] = 'Mostrar este bloque siempre';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_c9cc8cce247e49bae79f15173ce97354'] = 'Guardar';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_d1aa22a3126f04664e0fe3f598994014'] = 'Promociones especiales';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_c888438d14855d7d96a2724ee9c306bd'] = 'Actualización realizada con éxito';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_f4f70727dc34561dfde1a3c529b6205c'] = 'Configuración';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activado';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_b9f5c797ebbf55adccdd8539a65a0241'] = 'Desactivado';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_fd21fcc9fc4c1d5202d6fc11597b3fca'] = 'No hay promociones especiales en este momento';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_c2fb79a6eca86e519f938a1ef15c3e69'] = 'Añadir un bloque con promociones especiales';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_a8a670d89a6d2f3fa59942fc591011ef'] = 'Mostrar este bloque aunque no haya productos disponibles';
$_MODULE['<{pspagebuilder}prestashop>blockspecials_b4f95c1ea534936cc60c6368c225f480'] = 'Todas los promociones especiales';
