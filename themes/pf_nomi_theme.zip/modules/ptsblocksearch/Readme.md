Pts Prestashop Theme Framework for Prestashop 1.6.x

@package   ptsblocksearch
@version   2.0.0
@author    http://www.prestabrain.com
@copyright Copyright (C) October 2013 prestabrain.com <@emai:prestabrain@gmail.com>
               <info@prestabrain.com>.All rights reserved.
@license   GNU General Public License version 2